﻿Imports MySql.Data.MySqlClient
Public Class mFileExplorer
    Dim con As New MySqlConnection
    Dim result As Integer
    Dim da As New MySqlDataAdapter

    'MySqlCommand It represents a SQL statement to execute against a MySQL Database
    Dim cmd As New MySqlCommand



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        Mmenu.Show()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        con.ConnectionString = ("server=localhost;user id=medbaseadmin;password=medbasepass;database=medbase4")
        Try
            con.Open()
            With cmd
                .Connection = con

                .CommandText = "Select * from clients"
            End With

        Catch ex As Exception
            MsgBox(ex.Message)


        End Try
        con.Close()
        da.Dispose()
        filltable(dgtview)
    End Sub
    Public Sub filltable(ByVal dtgrd As Object)
        'declare a variable as new datatable
        Dim publictable As New DataTable
        Try
            'Gets or sets an SQL statement or stored procedure used to select records in the database.
            da.SelectCommand = cmd
            da.Fill(publictable)
            dtgrd.DataSource = publictable
            dtgrd.Columns(0).Visible = False

            da.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub
End Class