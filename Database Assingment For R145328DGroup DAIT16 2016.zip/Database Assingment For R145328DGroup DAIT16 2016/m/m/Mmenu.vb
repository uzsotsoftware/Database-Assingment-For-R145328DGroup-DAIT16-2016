﻿

Public Class Mmenu

    Private Sub RegisterToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegisterToolStripMenuItem.Click
        mRegistration.Show()

    End Sub

    Private Sub SearchToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchToolStripMenuItem.Click
        mSearch.Show()

    End Sub

    Private Sub ViewFilesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewFilesToolStripMenuItem.Click
        mFileExplorer.Show()
    End Sub

    Private Sub SettingsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SettingsToolStripMenuItem.Click
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
        Application.Exit()

    End Sub

    Private Sub Mmenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


    Private Sub RemoveUserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveUserToolStripMenuItem.Click
        mRemoveuser.Show()
    End Sub

    Private Sub ChangeCredentialsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangeCredentialsToolStripMenuItem.Click
        mChangecredentials.Show()
    End Sub
End Class
