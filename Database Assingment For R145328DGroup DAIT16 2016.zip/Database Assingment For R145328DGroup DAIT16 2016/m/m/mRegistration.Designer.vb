﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mRegistration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.sextxt = New System.Windows.Forms.ComboBox()
        Me.namel = New System.Windows.Forms.Label()
        Me.nametxt = New System.Windows.Forms.TextBox()
        Me.Surnametxt = New System.Windows.Forms.TextBox()
        Me.surnamel = New System.Windows.Forms.Label()
        Me.jobtxt = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.agetxt = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.mactxt = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.mastxt = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.policynumtxt = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.idnumtxt = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.passtext = New System.Windows.Forms.TextBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(254, 551)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Register"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'sextxt
        '
        Me.sextxt.FormattingEnabled = True
        Me.sextxt.Items.AddRange(New Object() {"Male", "Female"})
        Me.sextxt.Location = New System.Drawing.Point(141, 219)
        Me.sextxt.Name = "sextxt"
        Me.sextxt.Size = New System.Drawing.Size(121, 21)
        Me.sextxt.TabIndex = 2
        '
        'namel
        '
        Me.namel.AutoSize = True
        Me.namel.Location = New System.Drawing.Point(22, 61)
        Me.namel.Name = "namel"
        Me.namel.Size = New System.Drawing.Size(35, 13)
        Me.namel.TabIndex = 3
        Me.namel.Text = "Name"
        '
        'nametxt
        '
        Me.nametxt.Location = New System.Drawing.Point(141, 54)
        Me.nametxt.Name = "nametxt"
        Me.nametxt.Size = New System.Drawing.Size(100, 20)
        Me.nametxt.TabIndex = 4
        '
        'Surnametxt
        '
        Me.Surnametxt.Location = New System.Drawing.Point(141, 116)
        Me.Surnametxt.Name = "Surnametxt"
        Me.Surnametxt.Size = New System.Drawing.Size(100, 20)
        Me.Surnametxt.TabIndex = 6
        '
        'surnamel
        '
        Me.surnamel.AutoSize = True
        Me.surnamel.Location = New System.Drawing.Point(22, 123)
        Me.surnamel.Name = "surnamel"
        Me.surnamel.Size = New System.Drawing.Size(49, 13)
        Me.surnamel.TabIndex = 5
        Me.surnamel.Text = "Surname"
        '
        'jobtxt
        '
        Me.jobtxt.Location = New System.Drawing.Point(141, 300)
        Me.jobtxt.Name = "jobtxt"
        Me.jobtxt.Size = New System.Drawing.Size(100, 20)
        Me.jobtxt.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(22, 179)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(26, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Age"
        '
        'agetxt
        '
        Me.agetxt.Location = New System.Drawing.Point(141, 179)
        Me.agetxt.Name = "agetxt"
        Me.agetxt.Size = New System.Drawing.Size(100, 20)
        Me.agetxt.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(22, 227)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(25, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Sex"
        '
        'mactxt
        '
        Me.mactxt.Location = New System.Drawing.Point(229, 395)
        Me.mactxt.Name = "mactxt"
        Me.mactxt.Size = New System.Drawing.Size(100, 20)
        Me.mactxt.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(23, 303)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Occupation"
        '
        'mastxt
        '
        Me.mastxt.Location = New System.Drawing.Point(229, 352)
        Me.mastxt.Name = "mastxt"
        Me.mastxt.Size = New System.Drawing.Size(100, 20)
        Me.mastxt.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(23, 402)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(111, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Medical Aid Coverage"
        '
        'policynumtxt
        '
        Me.policynumtxt.Location = New System.Drawing.Point(229, 442)
        Me.policynumtxt.Name = "policynumtxt"
        Me.policynumtxt.Size = New System.Drawing.Size(100, 20)
        Me.policynumtxt.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(23, 442)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Policy Number"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 355)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(142, 13)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Medical Aid Service provider"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 263)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 13)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Id Number"
        '
        'idnumtxt
        '
        Me.idnumtxt.Location = New System.Drawing.Point(142, 256)
        Me.idnumtxt.Name = "idnumtxt"
        Me.idnumtxt.Size = New System.Drawing.Size(100, 20)
        Me.idnumtxt.TabIndex = 18
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(25, 551)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 20
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(356, 12)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(378, 517)
        Me.DataGridView1.TabIndex = 21
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(23, 499)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "Password"
        '
        'passtext
        '
        Me.passtext.Location = New System.Drawing.Point(229, 499)
        Me.passtext.Name = "passtext"
        Me.passtext.Size = New System.Drawing.Size(100, 20)
        Me.passtext.TabIndex = 23
        '
        'mRegistration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(746, 702)
        Me.Controls.Add(Me.passtext)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.idnumtxt)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.policynumtxt)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.mastxt)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.mactxt)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.agetxt)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.jobtxt)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Surnametxt)
        Me.Controls.Add(Me.surnamel)
        Me.Controls.Add(Me.nametxt)
        Me.Controls.Add(Me.namel)
        Me.Controls.Add(Me.sextxt)
        Me.Controls.Add(Me.Button1)
        Me.Name = "mRegistration"
        Me.Text = "Registration"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents sextxt As System.Windows.Forms.ComboBox
    Friend WithEvents namel As System.Windows.Forms.Label
    Friend WithEvents nametxt As System.Windows.Forms.TextBox
    Friend WithEvents Surnametxt As System.Windows.Forms.TextBox
    Friend WithEvents surnamel As System.Windows.Forms.Label
    Friend WithEvents jobtxt As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents agetxt As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents mactxt As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents mastxt As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents policynumtxt As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents idnumtxt As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents passtext As System.Windows.Forms.TextBox
End Class
