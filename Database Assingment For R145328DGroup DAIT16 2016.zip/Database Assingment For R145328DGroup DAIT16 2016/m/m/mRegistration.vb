﻿Imports MySql.Data.MySqlClient
Public Class mRegistration
    Dim con As New MySqlConnection
    Dim result As Integer
    Dim status As Boolean

    'MySqlCommand It represents a SQL statement to execute against a MySQL Database
    Dim cmd As New MySqlCommand

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
        Mmenu.Show()

    End Sub

    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'this line of is simply we copy this one from our form 
        con.ConnectionString = ("server=localhost;user id=medbaseadmin;password=medbasepass;database=medbase4")
        status = True
            If (nametxt.TextLength = 0) Then
            MsgBox("Enter name")
            status = False
            ElseIf (Surnametxt.TextLength = 0) Then
            MsgBox("Enter surname")
            status = False
            ElseIf (agetxt.TextLength = 0) Then
            MsgBox("Enter age")
            status = False
            ElseIf (sextxt.ValueMember = " ") Then
            MsgBox("Enter gender")
            status = False
            ElseIf (idnumtxt.TextLength = 0) Then
            MsgBox("Enter id number")
            status = False
            ElseIf (jobtxt.TextLength = 0) Then
            MsgBox("Enter occupation")
            status = False
            ElseIf (mastxt.TextLength = 0) Then
            MsgBox("Enter medical aid service provider")
            status = False
            ElseIf (mactxt.TextLength = 0) Then
            MsgBox("Enter service scheme")
            status = False
            ElseIf (policynumtxt.TextLength = 0) Then
            MsgBox("Enter policy number")
            status = False
            ElseIf (passtext.TextLength = 0) Then
            MsgBox("Enter password")
            status = False
            End If
        If (status = True) Then
            Try
                'we open Connection
                con.Open()

                With cmd
                    .Connection = con
                    .CommandText = "INSERT INTO `medbase4`.`clients` (`firstname`, `surname`, `age`, `sex`, `idnumber`, `occupation`, `serviceprovider`, `medicalscheme`, `policynumber`, `passwrd`) " & _
                                    "VALUES ('" & nametxt.Text & "','" & Surnametxt.Text & "','" & agetxt.Text & "','" & sextxt.Text & "', '" & idnumtxt.Text & "', '" & jobtxt.Text & "', '" & mastxt.Text & "', '" & mactxt.Text & "', '" & policynumtxt.Text & "','" & passtext.Text & "');"
                    'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                    result = cmd.ExecuteNonQuery
                    'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                    If result = 0 Then
                        MsgBox("Data has been Inserted!")
                    Else
                        MsgBox("Successfully saved!")

                    End If
                End With
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            con.Close()
        Else
            Me.Focus()

        End If
    End Sub

    Private Sub nametxt_TextChanged(sender As Object, e As EventArgs) Handles nametxt.TextChanged

    End Sub
End Class
