﻿Imports MySql.Data.MySqlClient
Public Class mRemoveuser
    Dim con As New MySqlConnection
    Dim result As Integer

    'MySqlCommand It represents a SQL statement to execute against a MySQL Database
    Dim cmd As New MySqlCommand


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
        Mmenu.Show()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
     
        Try
            Dim con As MySqlConnection = New MySqlConnection("server=localhost;user id=medbaseadmin;password=medbasepass;database=medbase4")
            Dim Query As String
            con.Open()
            Query =
            "DELETE FROM clients " & " WHERE firstname = '" & Me.rusertxt.Text & "'"
            Dim cmd As MySqlCommand = New MySqlCommand(Query, con)
            MsgBox(Query)
            Dim i As Integer = cmd.ExecuteNonQuery()
            If (i > 0) Then
                MsgBox("Record is Successfully Deleted")

            Else
                MsgBox("Record is not Deleted")

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        con.Close()
    End Sub
End Class