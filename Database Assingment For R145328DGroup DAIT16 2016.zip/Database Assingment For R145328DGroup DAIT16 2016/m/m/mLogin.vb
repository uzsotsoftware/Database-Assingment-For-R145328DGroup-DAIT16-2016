﻿Imports MySql.Data.MySqlClient

    Public Class mLogin
    Dim con As New MySqlConnection
    Dim result As Integer
    Dim sqladapter As New MySqlDataAdapter
    Dim sqlcmd As New MySqlCommand
    Dim dr As MySqlDataReader
    Dim pass1 As String
    Dim pass2 As String
        'MySqlCommand It represents a SQL statement to execute against a MySQL Database



        ' TODO: Insert code to perform custom authentication using the provided username and password 
        ' (See http://go.microsoft.com/fwlink/?LinkId=35339).  
        ' The custom principal can then be attached to the current thread's principal as follows: 
        '     My.User.CurrentPrincipal = CustomPrincipal
        ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
        ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
        ' such as the username, display name, etc.

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        'con.ConnectionString = ("server=localhost;user id=medbaseadmin;password=medbasepass;database=medbase4")
        Try
            'con.Open()

            MessageBox.Show("Connection to Database has been opened.")
            Dim connString As String = "server=localhost;user id=medbaseadmin;password=medbasepass;database=medbase4"
            Dim sqlQuery As String = "SELECT passwrd,firstname FROM clients WHERE firstname ='" & Me.usernametxt.Text & "'"
            Using sqlConn As New MySqlConnection(connString)
                Using sqlComm As New MySqlCommand()
                    With sqlComm
                        .Connection = sqlConn
                        .CommandText = sqlQuery
                        .CommandType = CommandType.Text
                        .Parameters.AddWithValue("@uname", usernametxt)
                    End With
                    Try
                        sqlConn.Open()
                        Dim sqlReader As MySqlDataReader = sqlComm.ExecuteReader()
                        While sqlReader.Read()
                            pass1 = sqlReader("passwrd").ToString()
                            pass2 = sqlReader("firstname").ToString()
                            If (pass1 = passwordtxt.Text) Then
                                Mmenu.Show()
                            Else
                                MsgBox("User not Found")
                            End If


                        End While
                    Catch ex As MySqlException
                        ' add your exception here '
                    End Try
                End Using
            End Using
        Catch myerror As MySqlException

            MessageBox.Show("Cannot connect to database: " & myerror.Message)

        Finally

            con.Dispose()

        End Try

    End Sub

        Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
            Me.Close()
        End Sub

        Private Sub loginformf_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        End Sub
    End Class
