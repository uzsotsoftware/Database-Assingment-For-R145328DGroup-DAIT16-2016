-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2016 at 11:54 PM
-- Server version: 5.5.49-log
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `medbase4`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `firstname` varchar(20) NOT NULL,
  `surname` varchar(45) NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(45) NOT NULL,
  `idnumber` varchar(45) NOT NULL,
  `occupation` varchar(45) NOT NULL,
  `serviceprovider` varchar(45) NOT NULL,
  `medicalscheme` varchar(45) NOT NULL,
  `policynumber` varchar(45) NOT NULL,
  `passwrd` varchar(45) NOT NULL,
  PRIMARY KEY (`firstname`,`idnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`firstname`, `surname`, `age`, `sex`, `idnumber`, `occupation`, `serviceprovider`, `medicalscheme`, `policynumber`, `passwrd`) VALUES
('cbr', 'shumba', 100, 'Male', '94849489484', 'job', 'cimas', 'gold', '28339393', '4321');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
